package com.apostpapad.dailytips;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class FavoriteActivity extends AppCompatActivity {
    private static final String TAG = "FavoriteActivity";

    private PreferencesConfig preferencesConfig;
    private int[] favoriteTipsIndexes;
    private int favoritesNum;
    private String[] tips;

    private TextView noFavoriteTipsTV;
    private ListView listView;
    private CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite);

        init();
    }

    private void init(){

        initLayout();

        tips = getResources().getStringArray(R.array.tips);

        preferencesConfig = new PreferencesConfig(this);
        favoriteTipsIndexes = preferencesConfig.readFavoriteTips();

        if(favoriteTipsIndexes.length==1 && favoriteTipsIndexes[0]==-1)
        {
            noFavoriteTipsTV.setText("No favorite Tips");
        }
        else {
            /*String l ="";
            for (int favoriteTipsIndex : favoriteTipsIndexes) {
                l += Integer.toString(favoriteTipsIndex)+", ";
            }*/
            noFavoriteTipsTV.setVisibility(View.INVISIBLE);

            favoritesNum = favoriteTipsIndexes.length;
             customAdapter = new CustomAdapter();
            listView.setAdapter(customAdapter);

        }

    }

    private void initLayout()
    {
        noFavoriteTipsTV = findViewById(R.id.noFavoriteTipsTextView);

        listView = findViewById(R.id.favoriteTipsListView);

    }

    private void removeFromFavorite(int position)
    {
        if(favoriteTipsIndexes.length>1) {
            Log.d(TAG, "removeFromFavorite: len>1");
            int[] favoriteTemp = new int[favoriteTipsIndexes.length - 1];
            {
                int counter=0;
                for(int i=0;i<favoriteTipsIndexes.length;i++)
                {
                    if(i!=position)
                    {
                        favoriteTemp[counter]=favoriteTipsIndexes[i];
                        Log.d(TAG, "removeFromFavorite: favTemp."+counter+" = "+favoriteTemp[counter]);
                        counter++;

                    }
                }
                favoriteTipsIndexes = favoriteTemp;
                favoritesNum = favoriteTipsIndexes.length;
                preferencesConfig.writeFavoriteTips(favoriteTemp);
                customAdapter.notifyDataSetChanged();
            }
        }
        else {
            Log.d(TAG, "removeFromFavorite: len=1");
            int[] favoriteTemp = new int[1];
            favoriteTemp[0]=-1;
            listView.setVisibility(View.INVISIBLE);
            noFavoriteTipsTV.setVisibility(View.VISIBLE);
            preferencesConfig.writeFavoriteTips(favoriteTemp);
        }

    }




    private class CustomAdapter extends BaseAdapter{


        @Override
        public int getCount() {
            return favoritesNum;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            convertView = getLayoutInflater().inflate(R.layout.favorite_tip_layout,null);

            TextView tipTV = convertView.findViewById(R.id.tipTextView);
            Log.d(TAG, "getView: position = "+position);
            tipTV.setText(tips[favoriteTipsIndexes[position]]);
            Button removeBtn = convertView.findViewById(R.id.removeButton);
            removeBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(FavoriteActivity.this, "Press remove on "+position , Toast.LENGTH_SHORT).show();
                    removeFromFavorite(position);
                }
            });


            return convertView;
        }
    }


}
