package com.apostpapad.dailytips;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Date;
import java.util.Random;

import static android.content.Context.CLIPBOARD_SERVICE;

public class HomeFragment extends Fragment {
    private static final String TAG = "HomeFragment";

    private PreferencesConfig preferencesConfig;
    private Date startDate, todayDate;
    private String[] tips;
    private int[] favoriteIndexes, downVotedIndexes;
    private int shownTipIndex,dayDiff;
    private boolean favoriteBool, downVotedBool;

    private TextView dayTextView, tipTextVIew;
    private Button favoriteBtn, settingsBtn, shareBtn, addTipBtn, downVoteBtn, copyToClipBoardBtn, heartButton;
    private String showingTip;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);


        initLayout(view);
        init();


        return view;
    }

    private void init() {

        favoriteBool = false;
        downVotedBool = false;

        preferencesConfig = new PreferencesConfig(getContext());

        favoriteIndexes = preferencesConfig.readFavoriteTips();
        downVotedIndexes = preferencesConfig.readDownVotedTips();


        startDate = preferencesConfig.readStartDay();
        todayDate = new Date(System.currentTimeMillis());


        if (!startDate.after(new Date(0))) {
            Log.d(TAG, "New startDate Added.");
            preferencesConfig.writeStartDay(todayDate);
            startDate = preferencesConfig.readStartDay();
        }
         dayDiff = getDifferenceDays(startDate, todayDate) + 0;
        Toast.makeText(getContext(), "Diff = " + dayDiff, Toast.LENGTH_SHORT).show();


        // TIPS
        tips = getResources().getStringArray(R.array.tips);


        shownTipIndex = (dayDiff % tips.length) - 1;
        dayTextView.setText("Day " + dayDiff);
        showTip();
    }


    private void initLayout(View view) {


        dayTextView = view.findViewById(R.id.dayTV);
        tipTextVIew = view.findViewById(R.id.tipTextView);

/*
        downVoteBtn = view.findViewById(R.id.downVoteButton);
        downVoteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "downvoted", Toast.LENGTH_SHORT).show();
               addToDownVoted();
            }
        });
*/
        copyToClipBoardBtn = view.findViewById(R.id.copyButton);
        copyToClipBoardBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "Copyed", Toast.LENGTH_SHORT).show();

                ClipboardManager clipboard = (ClipboardManager) getContext().getSystemService(CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("label", showingTip);
                clipboard.setPrimaryClip(clip);
            }
        });

        heartButton = view.findViewById(R.id.heartButton);
        heartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "heartButton", Toast.LENGTH_SHORT).show();
                addToFavorites();
            }
        });

        shareBtn = view.findViewById(R.id.shareButton);
        shareBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "sharebtn", Toast.LENGTH_SHORT).show();


                String shareBody = "Day "+dayDiff+" : "+showingTip+"\nShare via the "+getString(R.string.app_name)+ " app.";
                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Tip of the Day");
                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                startActivity(Intent.createChooser(sharingIntent, "Share using.."));

            }
        });


    }

    public void showTip() {
        Random random = new Random(System.currentTimeMillis());
        int chance = random.nextInt(1000);
        String[] userAddedTips = preferencesConfig.readUserAddedTipsArray();
        if (userAddedTips.length == 1 && userAddedTips[0].equals("-1")) {
            Log.d(TAG, "showTip: empty user added tips array, show from xml.");
            showingTip = tips[shownTipIndex];

        } else {
            if (chance < 100) // 10% chance of reading user added tips
            {
                Log.d(TAG, "showTip: show tip from user added tip array");
                showingTip = userAddedTips[random.nextInt(userAddedTips.length)];


            } else {
                Log.d(TAG, "showTip: show tip from xml");
                showingTip = tips[shownTipIndex];
            }
        }

        tipTextVIew.setText(showingTip);

/*
        if (isDownVoted()) {
            downVotedBool = true;
            tipTextVIew.setTextColor(Color.RED);
        } else if (isFavorite()) {
            favoriteBool = true;
            tipTextVIew.setTextColor(Color.GREEN);
        }
        tipTextVIew.setText(tips[shownTipIndex]);
        */
    }

    public int getDifferenceDays(Date d1, Date d2) {
        int daysdiff = 0;
        long diff = d2.getTime() - d1.getTime();
        long diffDays = diff / (24 * 60 * 60 * 1000) + 1;
        daysdiff = (int) diffDays;
        return daysdiff;
    }

    public void addToFavorites() {
      /*  if (downVotedBool) {
            removeFromDownVoted();
        }*/
        if (!favoriteBool) {
            Toast.makeText(getContext(), "Added to favorites.", Toast.LENGTH_SHORT).show();
            int[] favoritesTemp = new int[favoriteIndexes.length + 1];
            System.arraycopy(favoriteIndexes, 0, favoritesTemp, 0, favoriteIndexes.length);
            favoritesTemp[favoriteIndexes.length] = shownTipIndex;
            preferencesConfig.writeFavoriteTips(favoritesTemp);
            downVotedBool = false;
            favoriteBool = true;
            tipTextVIew.setTextColor(Color.GREEN);
            favoriteIndexes = favoritesTemp;
        } else {
            Toast.makeText(getContext(), "Already favorite.", Toast.LENGTH_SHORT).show();
        }
    }


    public void addToDownVoted() {
        if (favoriteBool) {
            removeFromFavorites();
        }
        if (!downVotedBool) {
            Toast.makeText(getContext(), "Added to downVoted.", Toast.LENGTH_SHORT).show();
            int[] downVotedTemp = new int[downVotedIndexes.length + 1];
            System.arraycopy(downVotedIndexes, 0, downVotedTemp, 0, downVotedIndexes.length);
            downVotedTemp[downVotedIndexes.length] = shownTipIndex;
            preferencesConfig.writeDownVotedTips(downVotedTemp);
            downVotedBool = true;
            favoriteBool = false;
            //      tipTextVIew.setTextColor(Color.RED);
            downVotedIndexes = downVotedTemp;
        } else {
            Toast.makeText(getContext(), "Already down voted.", Toast.LENGTH_SHORT).show();
        }
    }

    //Remove index from favorites if it goes to down voted

    public void removeFromFavorites() {
        int[] favoritesTemp;
        Log.d(TAG, "removeFromFavorites: favoriteArray Len: " + favoriteIndexes.length);
        if (favoriteIndexes.length == 1) {
            favoritesTemp = new int[1];
            favoritesTemp[0] = -1;
        } else {
            favoritesTemp = new int[favoriteIndexes.length - 1];
            int count = 0;
            for (int i = 0; i < favoriteIndexes.length; i++) {

                if (favoriteIndexes[i] != shownTipIndex) {
                    Log.d(TAG, "removeFromFav: tip gone in " + favoriteIndexes[i]);
                    favoritesTemp[count] = favoriteIndexes[i];
                    count++;
                }
            }
            Toast.makeText(getContext(), "Removed from favorites", Toast.LENGTH_SHORT).show();
            Log.d(TAG, "removeFromFavorites: old fav len = " + favoriteIndexes.length + "  new len = " + favoritesTemp.length);

        }
        preferencesConfig.writeFavoriteTips(favoritesTemp);
    }

    //Remove index from down voted if it goes to favorites
    public void removeFromDownVoted() {
        int[] downVotedTemp;
        Log.d(TAG, "removeFromFavorites: favoriteArray Len: " + favoriteIndexes.length);
        if (downVotedIndexes.length == 1) {
            downVotedTemp = new int[1];
            downVotedTemp[0] = -1;
        } else {


            downVotedTemp = new int[downVotedIndexes.length - 1];
            Log.d(TAG, "removeFromDownVoted: temp len = " + downVotedTemp.length);
            for (int i = 0; i < downVotedIndexes.length; i++) {
                if (downVotedIndexes[i] != shownTipIndex) {
                    Log.d(TAG, "removeFromDownVoted: tip gone in " + downVotedIndexes[i]);
                    downVotedTemp[i] = downVotedIndexes[i];

                }
            }
            Toast.makeText(getContext(), "Removed from down voted", Toast.LENGTH_SHORT).show();
            Log.d(TAG, "removeFromDownVoted: old down len = " + downVotedIndexes.length + " new len = " + downVotedTemp.length);
        }
        preferencesConfig.writeDownVotedTips(downVotedTemp);
    }

    //Check if tip is in favorites
    public boolean isFavorite() {
        for (int favoriteIndex : favoriteIndexes) {
            if (favoriteIndex == shownTipIndex) {
                return true;
            }
        }
        return false;
    }

    //Check if tip is in down voted list
    public boolean isDownVoted() {
        for (int downVotedIndex : downVotedIndexes) {
            if (downVotedIndex == shownTipIndex) {
                return true;
            }
        }
        return false;
    }

    //If array has only a "-1" then it means that it is empty
    public boolean isArrayEmpty(int[] array) {
        return array.length == 1 && array[0] == -1;
    }


}
