package com.apostpapad.dailytips;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private static final String TAG = "MainActivity";


    private DrawerLayout drawerLayout;
    private NavigationView navigationView;

    private Button drawerBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Utils.onActivityCreateSetTheme(this);

        setContentView(R.layout.activity_main);



        drawerBtn = findViewById(R.id.drawerButton);
        drawerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDrawer();
            }
        });

        drawerLayout = findViewById(R.id.drawer_layout);

        navigationView = findViewById(R.id.drawer_navigation_view);
        navigationView.setNavigationItemSelectedListener(this);
        if (savedInstanceState == null) {
            navigationView.setCheckedItem(R.id.item_home);
            //  navigationView.getMenu().getItem(0).setChecked(true);
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, new HomeFragment()).commit();

        }
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        String itemName = (String) menuItem.getTitle();
        Log.d(TAG, "onNavigationItemSelected: Clicked "+ itemName);



        switch (menuItem.getItemId()) {
            case R.id.item_home:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment, new HomeFragment()).commit();
                drawerBtn.setVisibility(View.VISIBLE);
                break;
            case R.id.item_favorites:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment, new FavoritesFragment()).commit();
                drawerBtn.setVisibility(View.VISIBLE);
                break;
            case R.id.item_add_tip:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment, new AddTipFragment()).commit();
                drawerBtn.setVisibility(View.VISIBLE);
                break;
            case R.id.item_settings:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment, new SettingsFragment()).commit();
                drawerBtn.setVisibility(View.INVISIBLE);
                break;

        }

        closeDrawer();


        return true;
    }

    private void closeDrawer() {
        drawerLayout.closeDrawer(GravityCompat.START);
    }

    private void openDrawer() {
        drawerLayout.openDrawer(GravityCompat.START);
    }



    private void enableNotification()
    {
        Calendar calendar = Calendar.getInstance();

        calendar.set(Calendar.HOUR_OF_DAY,2);
        calendar.set(Calendar.MINUTE,9);
        calendar.set(Calendar.SECOND,0);

        Intent intent = new Intent(getApplicationContext(), Notification_receiver.class);
        intent.setAction("MY_NOTIFICATION_MESSAGE");

        PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(),100,intent,PendingIntent.FLAG_UPDATE_CURRENT);

        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            closeDrawer();
        }else if (navigationView.getCheckedItem()!=navigationView.getMenu().getItem(0)){
            //If fragment not home, onBack go to home fragment
            navigationView.setCheckedItem(R.id.item_home);
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, new HomeFragment()).commit();
            drawerBtn.setVisibility(View.VISIBLE);

        }

        else {


            super.onBackPressed();
        }
    }
}
