package com.apostpapad.dailytips;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.Context.CONNECTIVITY_SERVICE;

public class AddTipFragment extends Fragment {
    private static final String TAG = "AddTipFragment";

    private static ApiInterface apiInterface;

    private PreferencesConfig preferencesConfig;

    private EditText tipEditText;
    private Button addTipBtn;
    private CheckBox uploadCheckbox;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_tip,container,false);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);

        preferencesConfig = new PreferencesConfig(getContext());
        initLayout(view);
        return view;
    }

    private void initLayout(View view)
    {

        uploadCheckbox = view.findViewById(R.id.uploadCheckBox);
        uploadCheckbox.setChecked(preferencesConfig.readUloadCheckboxStatus());
        uploadCheckbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                {
                    preferencesConfig.writeUloadCheckboxStatus(true);
                }
                else {
                    preferencesConfig.writeUloadCheckboxStatus(false);
                }
            }
        });

        tipEditText = view.findViewById(R.id.tipEditText);

        addTipBtn = view.findViewById(R.id.addTipButton);
        addTipBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(tipEditText.getText().toString().trim().length()>0)
                {
                    Toast.makeText(getContext(), "Added Tip : " + tipEditText.getText().toString().trim(), Toast.LENGTH_SHORT).show();

                    if(uploadCheckbox.isChecked())
                    {
                        if(isOnline(getContext())) {
                            uploadTipToServer(tipEditText.getText().toString().trim());
                        }else {
                            Toast.makeText(getContext(), "No internet connection.", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else {
                        Toast.makeText(getContext(), "Device only Tip : " + tipEditText.getText().toString().trim(), Toast.LENGTH_SHORT).show();

                    }
                preferencesConfig.writeUserAddedTipToArray( tipEditText.getText().toString().trim());
                }else{
                    Toast.makeText(getContext(), "No text " + tipEditText.getText().toString().trim(), Toast.LENGTH_SHORT).show();

                }
            }
        });
/*
        addToServerBtn = view.findViewById(R.id.addToServerButton);
        addToServerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(tipEditText.getText().toString().trim().length()>0)
                {
                Toast.makeText(getContext(), "Server : "+tipEditText.getText().toString().trim(), Toast.LENGTH_SHORT).show();
                if(isOnline(getContext())) {
                    uploadTipToServer(tipEditText.getText().toString().trim());
                }else {
                    Toast.makeText(getContext(), "No internet connection.", Toast.LENGTH_SHORT).show();
                }
                }else{
                    Toast.makeText(getContext(), "No text " + tipEditText.getText().toString().trim(), Toast.LENGTH_SHORT).show();

                }
            }
        });*/
    }

    private void uploadTipToServer(String tipString){

        Call<Tip> uploadTip = apiInterface.uploadTip(tipString);
        uploadTip.enqueue(new Callback<Tip>() {
            @Override
            public void onResponse(Call<Tip> call, Response<Tip> response) {
                assert response.body() != null;
                String uploadResponse = response.body().getResponse();
                if(uploadResponse.equals("TipAdded"))
                {
                    Toast.makeText(getContext(), "Uploaded!!", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(getContext(), "Error Uploading. Please try again later.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Tip> call, Throwable t) {
                Toast.makeText(getContext(), "Error Uploading Tip.", Toast.LENGTH_SHORT).show();
            }
        });
    }


    public static boolean isOnline(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context
                .getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }

}
