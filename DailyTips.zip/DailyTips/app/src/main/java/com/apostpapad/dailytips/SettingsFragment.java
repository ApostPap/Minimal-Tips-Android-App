package com.apostpapad.dailytips;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.preference.CheckBoxPreference;
import android.support.v7.preference.ListPreference;
import android.support.v7.preference.Preference;
import android.support.v7.preference.PreferenceFragmentCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.Calendar;

import static android.content.Context.ALARM_SERVICE;

public class SettingsFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        getFragmentManager().beginTransaction().replace(R.id.fragment, new SettingsPrefFragment()).commit();
        return view;
    }

    public static class SettingsPrefFragment extends PreferenceFragmentCompat {

        private int clickCounter = 0;
        private PreferencesConfig preferencesConfig;
        private boolean ad_pauseBool;
        private ListPreference themesPref;


        @Override
        public void onCreatePreferences(Bundle bundle, String s) {
            addPreferencesFromResource(R.xml.preferences);

            initPref();
        }

        private void initPref() {

            preferencesConfig = new PreferencesConfig(getContext());
            ad_pauseBool = preferencesConfig.readAdPause();


            //Become Premium Button
            android.support.v7.preference.Preference becomePremiumPref = findPreference(getString(R.string.key_become_premium));
            becomePremiumPref.setOnPreferenceClickListener(new android.support.v7.preference.Preference.OnPreferenceClickListener() {
                @Override
                public boolean onPreferenceClick(android.support.v7.preference.Preference preference) {
                    if(preferencesConfig.readPremiumStatus()) {
                        Toast.makeText(getContext(), "Already Premium", Toast.LENGTH_SHORT).show();
                    }else
                    {
                        preferencesConfig.writePremiumStatus(true);
                        Toast.makeText(getContext(), "Become Premium", Toast.LENGTH_SHORT).show();
                    }
                    return false;
                }
            });


           themesPref = (ListPreference) findPreference(getString(R.string.key_themes));
           themesPref.setEnabled(preferencesConfig.readPremiumStatus());
            themesPref.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object o) {

                        String themeValue = o.toString();


                        if (themeValue.equals(getString(R.string.theme_minimal_white))) {
                            Toast.makeText(getContext(), "Switch to white", Toast.LENGTH_SHORT).show();
                        } else if (themeValue.equals(getString(R.string.theme_dark_night))) {
                            Toast.makeText(getContext(), "Switch to black", Toast.LENGTH_SHORT).show();
                        }
                        return true;

                }

            });


            //Clear All Favorites Button
            android.support.v7.preference.Preference clearFavoritesPref = findPreference(getString(R.string.key_clear_favorites));

            clearFavoritesPref.setOnPreferenceClickListener(new android.support.v7.preference.Preference.OnPreferenceClickListener(){
                @Override
                public boolean onPreferenceClick(android.support.v7.preference.Preference preference) {
                    int[] favArr = preferencesConfig.readFavoriteTips();
                    if(favArr.length==1 && favArr[0]==-1){
                        Toast.makeText(getContext(), "You have no favorite tips.", Toast.LENGTH_SHORT).show();
                    }else {

                        int[] tempArr = new int[1];
                        tempArr[0] = -1;
                        preferencesConfig.writeFavoriteTips(tempArr);
                        if(favArr.length>1){
                        Toast.makeText(getContext(), "Cleared "+favArr.length+" tips.", Toast.LENGTH_SHORT).show();
                    }else {
                            Toast.makeText(getContext(), "Cleared "+favArr.length+" tip.", Toast.LENGTH_SHORT).show();
                        }}
                    return false;
                }
            });


            android.support.v7.preference.Preference versionPref = findPreference(getString(R.string.key_version));
            versionPref.setOnPreferenceClickListener(new android.support.v7.preference.Preference.OnPreferenceClickListener() {
                @Override
                public boolean onPreferenceClick(android.support.v7.preference.Preference preference) {
                    clickCounter++;
                    //   Toast.makeText(getContext(), ""+clickCounter, Toast.LENGTH_SHORT).show();
                    if (!ad_pauseBool) {
                        if (clickCounter > 14 && clickCounter < 20) {
                            Toast.makeText(getContext(), "Answer 42.", Toast.LENGTH_SHORT).show();
                        } else if (clickCounter > 20) {
                            Toast.makeText(getContext(), "...", Toast.LENGTH_SHORT).show();
                            preferencesConfig.writeAdPause(true);
                            ad_pauseBool = true;
                        }
                    } else {
                        Toast.makeText(getContext(), ".", Toast.LENGTH_SHORT).show();
                    }
                    return false;
                }
            });


            //Rate Us Button
            android.support.v7.preference.Preference ratePref = findPreference(getString(R.string.key_rate_app));
            ratePref.setOnPreferenceClickListener(new android.support.v7.preference.Preference.OnPreferenceClickListener() {
                @Override
                public boolean onPreferenceClick(android.support.v7.preference.Preference preference) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.papad.apost.liveframe")));
                    } catch (ActivityNotFoundException e) {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.papad.apost.liveframe")));
                    }
                    return false;
                }
            });



            final CheckBoxPreference notifyCheckBoxPreference = (CheckBoxPreference) findPreference(getString(R.string.key_notify_daily));
                notifyCheckBoxPreference.setChecked(preferencesConfig.readNotifyDailyStatus());
                notifyCheckBoxPreference.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                @Override
                public boolean onPreferenceClick(Preference preference) {
                    if (notifyCheckBoxPreference.isChecked()) {
                        enableNotification();
                        preferencesConfig.writeNotifyDailyStatus(true);
                        Toast.makeText(getContext(), "chec", Toast.LENGTH_SHORT).show();
                    } else {
                        preferencesConfig.writeNotifyDailyStatus(false);
                        Toast.makeText(getContext(), "ttt", Toast.LENGTH_SHORT).show();
                    }
                    return false;
                }
            });



            /*

            // Send Feedback Button
            Preference feedbackPref = findPreference(getString(R.string.key_send_feedback));
            feedbackPref.setOnPreferenceClickListener(new  android.support.v7.preference.Preference.OnPreferenceClickListener() {
                public boolean onPreferenceClick(android.support.v7.preference.Preference preference) {
                    //   sendFeedback();
                    startActivity(new Intent(context, SendFeedbackActivity.class));
                    return false;
                }
            });*/

        }

        private void enableNotification()
        {
            Calendar calendar = Calendar.getInstance();

            calendar.set(Calendar.HOUR_OF_DAY,2);
            calendar.set(Calendar.MINUTE,10);
            calendar.set(Calendar.SECOND,40);

            Intent intent = new Intent(getContext(), Notification_receiver.class);
            intent.setAction("MY_NOTIFICATION_MESSAGE");

            PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(),100,intent,PendingIntent.FLAG_UPDATE_CURRENT);

            AlarmManager alarmManager = (AlarmManager) getContext().getSystemService(ALARM_SERVICE);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);
        }





    }



}
