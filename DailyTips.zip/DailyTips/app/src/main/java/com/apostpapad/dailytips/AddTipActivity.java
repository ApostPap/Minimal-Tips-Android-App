package com.apostpapad.dailytips;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddTipActivity extends AppCompatActivity {

    private EditText tipEditText;
    private Button addToServerBtn,addToDeviceBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_tip);

        initLayout();
    }

    private void initLayout()
    {
        tipEditText = findViewById(R.id.tipEditText);

        addToDeviceBtn = findViewById(R.id.addTipButton);
        addToDeviceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(AddTipActivity.this, "Device : "+tipEditText.getText().toString().trim(), Toast.LENGTH_SHORT).show();
            }
        });

        addToServerBtn = findViewById(R.id.addToServerButton);
        addToServerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(AddTipActivity.this, "Server : "+tipEditText.getText().toString().trim(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}
